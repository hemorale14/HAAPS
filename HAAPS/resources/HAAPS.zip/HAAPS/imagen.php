<?php
    //session_start();
	echo '<img src="ajax/imagen.php" width="162" height="53"/>';
	//echo 'hi';
	//echo '<br/>' .$_SESSION['cadena'];
?>